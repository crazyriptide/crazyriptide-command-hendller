const { EmbedBuilder } = require("discord.js")

module.exports = {
  name: "embed",
  description: "embed command.",
  cooldown: 3000,
  run: async (client, interaction) => {
    const embed = new EmbedBuilder()
    .setTitle(interaction.guild.name)
    .setDescription(`${interaction.user}`)
    .setColor("DarkVividPink")
    .setFooter({text: `${interaction.guild.name}`, iconURL: interaction.guild.iconURL()})
    .setTimestamp()

    interaction.reply({embeds: [embed]})
  },
};
