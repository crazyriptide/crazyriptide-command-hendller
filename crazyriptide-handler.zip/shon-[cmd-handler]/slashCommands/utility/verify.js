const { EmbedBuilder, ButtonBuilder, ActionRowBuilder } = require("discord.js")

module.exports = {
  name: "verify",
  description: "verify command.",
  cooldown: 3000,
  run: async (client, interaction) => {

    const embed = new EmbedBuilder()
    .setAuthor({name: interaction.guild.name, iconURL: interaction.guild.iconURL()})
    .setDescription(`\`\`\`Verify your self!\`\`\``)
    .setColor("DarkVividPink")
    .setFooter({text: interaction.guild.name, iconURL: interaction.guild.iconURL()})
    .setTimestamp()

    const buttons = new ButtonBuilder()
    .setCustomId("verify")
    .setLabel("verify")
    .setEmoji("✅")
    .setStyle("Success")


    const row = new ActionRowBuilder()
    .addComponents(buttons)

    interaction.reply({embeds: [embed], components: [row]})
  },
};
