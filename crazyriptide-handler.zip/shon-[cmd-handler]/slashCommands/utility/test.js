module.exports = {
  name: "test",
  description: "test command.",
  cooldown: 3000,
  run: async (client, interaction) => {
    console.log("test command works!")
  },
};