const chalk = require("chalk");
const client = require("..");
const { ActivityType } = require("discord.js")

client.on("ready", () => {

  console.log(chalk.green(`[${client.user.username}] Running.`))

  const guild = client.guilds.cache.get(process.env.guild)

  setInterval(() => client.user.setActivity({ name: 'Custom Status', state: `${guild.memberCount}`, type: ActivityType.Custom }), 10000)
  
})