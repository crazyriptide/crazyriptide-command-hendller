const { EmbedBuilder } = require("discord.js");
const client = require("..");

client.on("guildMemberAdd", (member) => {
  const channel = client.channels.cache.get(process.env.welcome);

  const embed = new EmbedBuilder()
    .setColor("White")
    .setTitle(`__${member.guild.name} Member!__`)
    .setDescription(`**Welcome ${member.user} to the ${member.guild.name}!\nYou're the \`${member.guild.memberCount}\` member in the guild.**`)
    .setFooter({ text: member.guild.name, iconURL: member.guild.iconURL() })
    .setThumbnail(member.user.displayAvatarURL({ format: "png" }));

  channel.send({ embeds: [embed] });
});
