const { EmbedBuilder } = require("discord.js");

module.exports = {
  name: "say",
  description: "say command.",
  cooldown: 3000,
  userPerms: "Administrator",
  run: async (client, message, args) => {

    const embed = new EmbedBuilder()
    .setAuthor({name: message.guild.name, iconURL: message.guild.iconURL()})
    .setDescription(`\`\`\`${args}\`\`\``)
    .setColor("DarkVividPink")
    .setFooter({text: message.guild.name, iconURL: message.guild.iconURL()})
    .setTimestamp()

    message.reply({embeds: [embed]})
  },
};